#pragma once

struct File {
	int NUM_ROWS = 0; 
	int NUM_COLS = 0; 
	int pokemonsPuebloPaleta = 0;
	int pokemonsToUnlockForest = 0;
	int pokemonsForest = 0;
	int pokemonsToUnlockCave = 0;
	int pikachuPower = 0;
	int healthPokemons = 0;
	int healthMewtwo = 0;
	int minTimePokemons = 0;
	int maxTimePokemons = 0;
	File();
};