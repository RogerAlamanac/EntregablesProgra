#pragma once

struct Position {
	int x;
	int y;
};