#pragma once

void PrintCharizard();
void PrintPikachu();
void PrintMewtwo();
void PrintLogo();
void PrintMenu(int selected);